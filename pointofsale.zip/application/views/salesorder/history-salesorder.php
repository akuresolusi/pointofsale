<div class="main-content">
	<div class="container-fluid">
		<div class="row" style="margin-top: -15px;">
	        <div class="col-xs-12 result-mobile" style="border-top: none; margin-top: 5px;">
	        	<div class="col-xs-3">
	        		<h3>29</h3>
	        		<p id="date">Agustus</p>
	        	</div>
	        	<div class="col-xs-9" style="padding-left: 0">
        			<p id="no">INV/1234/212</p>
        		</div>
	        	<div class="col-xs-9" style="padding-left: 0">
	        		<p id="name">Firman</p>
	        	</div>
	        	<div class="col-xs-9" style="padding-left: 0">
	        		<p id="done">Transaksi Selesai</p>
	        	</div>
        	</div>
	        <div class="col-xs-12 result-mobile" style="border-top:none; margin-top: 5px; ">
	        	<div class="col-xs-3">
	        		<h3>12</h3>
	        		<p id="date">Juli</p>
	        	</div>
	        	<div class="col-xs-9" style="padding-left: 0">
        			<p id="no">INV/1234/212</p>
        		</div>
	        	<div class="col-xs-9" style="padding-left: 0">
	        		<p id="name">Agus Setiawan</p>
	        	</div>
	        	<div class="col-xs-9" style="padding-left: 0">
	        		<p id="done">Transaksi Selesai</p>
	        	</div>
	        </div>
	    </div>
	</div>
</div>