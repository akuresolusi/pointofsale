<div class="main-content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12 profit-mobile">
				<div class="col-xs-5 target-mobile">
					<p id="result">Rp. 2.000.000</p>
					<p id="dsc">Income</p>
				</div>
				<div class="col-xs-2 line nopadding">|</div>
				<div class="col-xs-5 target-mobile">
					<p id="target">Rp. 10.000.000</p>
					<p id="dsc">Goals</p>
				</div>
			</div>
			<div class="container">
				<div class="col-xs-12 transaction-mobile">
					<div class="col-xs-6 nopadding">
						<p id="today">Hari Ini</p>
						<p id="trans">10 Transaksi</p>
					</div>
					<div class="col-xs-6 nopadding">
						<p id="todaymoney">Rp. 587.000</p>
					</div>
				</div>
			</div>
			<div class="col-xs-12 category-mobile">
				<div class="col-xs-2 icon-category">
					<img src="<?php echo base_url() ?>assets/img/flaticon/kaos.png" style="width: 100%">
				</div>
				<div class="col-xs-5 nopadding">
					<p id="cat-item">TShirt</p>
					<p id="cat-desc">5 Transaksi</p>
				</div>
				<div class="col-xs-5">
					<p id="todaymoney">Rp. 187.000</p>
				</div>
			</div>
			<div class="col-xs-12 category-mobile">
				<div class="col-xs-2 icon-category">
					<img src="<?php echo base_url() ?>assets/img/flaticon/celana.png" style="width: 100%">
				</div>
				<div class="col-xs-5 nopadding">
					<p id="cat-item">Celana Panjang</p>
					<p id="cat-desc">0 Transaksi</p>
				</div>
				<div class="col-xs-5">
					<p id="todaymoney">Rp. 253.000</p>
				</div>
			</div>
		</div>
	</div>
</div>